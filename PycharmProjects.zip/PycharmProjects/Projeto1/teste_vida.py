acordar_as8 = True
fome = False
if acordar_as8 and fome:
    print('Levantar para arrumar o cafe')
elif acordar_as8 and not (fome):
    print('Ir tomar banho')
else:
    print('Hora de preparar o almoco')
elif not acordar_as8 and not (fome)
    print('Hora de preparar o almoco')
