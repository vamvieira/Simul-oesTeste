
personagem_nome = 'Vitor'
personagem_idade = '23'
personagem_esporte = 'Futebol'
personagem_jogo = 'Rust'

print('Meu nome e ' + personagem_nome + ',')
print('Eu tenho ' + personagem_idade + ' anos de idade.')
print('Meu esporte favorito e o ' + personagem_esporte)
print('Eu gosto de jogar ' + personagem_jogo + ' nas minha horas vagas.')

nome = 'meu nome e vitor neusonlonomos'
print(nome.count('o'))

var= "James Bond"
print(var[2::-1])


listOne = [20, 40, 60, 80]
listTwo = [20, 40, 60, 80]

print(listOne == listTwo)
print(listOne is listTwo)